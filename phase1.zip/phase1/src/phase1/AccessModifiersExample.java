package phase1;

//Parent class with different access modifiers
class Parent {
 public String publicVariable = "This is a public variable";
 private String privateVariable = "This is a private variable";
 protected String protectedVariable = "This is a protected variable";

 public void publicMethod() {
     System.out.println("This is a public method");
 }

 private void privateMethod() {
     System.out.println("This is a private method");
 }

 protected void protectedMethod() {
     System.out.println("This is a protected method");
 }
}

//Child class inheriting from Parent class
class Child extends Parent {
 public void accessParentVariablesAndMethods() {
     System.out.println(publicVariable);    // Accessible
     //System.out.println(privateVariable); // Not accessible (private)
     System.out.println(protectedVariable); // Accessible
     publicMethod();                        // Accessible
     //privateMethod();                      // Not accessible (private)
     protectedMethod();                     // Accessible
 }
}

//Main class to test the access modifiers
public class AccessModifiersExample {
 public static void main(String[] args) {
     Parent parent = new Parent();
     System.out.println(parent.publicVariable);    // Accessible
     //System.out.println(parent.privateVariable); // Not accessible (private)
     System.out.println(parent.protectedVariable); // Not accessible (protected)
     parent.publicMethod();                        // Accessible
     //parent.privateMethod();                      // Not accessible (private)
     parent.protectedMethod();                     // Not accessible (protected)

     Child child = new Child();
     child.accessParentVariablesAndMethods();
 }
}

