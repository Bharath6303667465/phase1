package phase1;

public class MethodExample {
    // Method without parameters and return value
    public void greet() {
        System.out.println("Hello! Welcome to the program.");
    }

    // Method with parameters and return value
    public int add(int num1, int num2) {
        return num1 + num2;
    }

    // Method with parameter but no return value
    public void printMessage(String message) {
        System.out.println("Message: " + message);
    }

    // Method with return value but no parameters
    public double getRandomNumber() {
        return Math.random();
    }

    public static void main(String[] args) {
        MethodExample example = new MethodExample();

        // Calling a method without parameters and return value
        example.greet();

        // Calling a method with parameters and return value
        int result = example.add(5, 3);
        System.out.println("Addition Result: " + result);

    }
}
