package phase1;

public class StringConversionExample {
    public static void main(String[] args) {
        // Creating a string
        String str = "Hello, World!";

        // Converting string to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(str);

        // Converting string to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(str);

        // Displaying the original string
        System.out.println("Original String: " + str);

        // Displaying the StringBuffer
        System.out.println("StringBuffer: " + stringBuffer);

        // Displaying the StringBuilder
        System.out.println("StringBuilder: " + stringBuilder);
    }
}
