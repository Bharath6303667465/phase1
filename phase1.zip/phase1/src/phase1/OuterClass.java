package phase1;

public class OuterClass {
    private int outerData;

    public OuterClass(int outerData) {
        this.outerData = outerData;
    }

    // Inner class
    public class InnerClass {
        private int innerData;

        public InnerClass(int innerData) {
            this.innerData = innerData;
        }

        public void display() {
            System.out.println("Outer Data: " + outerData);
            System.out.println("Inner Data: " + innerData);
        }
    }

    public static void main(String[] args) {
        // Creating an instance of the outer class
        OuterClass outerObj = new OuterClass(10);

        // Creating an instance of the inner class
        InnerClass innerObj = outerObj.new InnerClass(20);

        // Accessing the inner class method
        innerObj.display();
    }
}

