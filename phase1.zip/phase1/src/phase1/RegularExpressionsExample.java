package phase1;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpressionsExample {
    public static void main(String[] args) {
        // Regular expression pattern
        String pattern = "a*b";

        // Input string
        String input = "aaab";

        // Create a Pattern object
        Pattern regexPattern = Pattern.compile(pattern);

        // Create a Matcher object
        Matcher matcher = regexPattern.matcher(input);

        // Check if the pattern matches the input
        boolean matches = matcher.matches();

        if (matches) {
            System.out.println("Pattern matches the input string.");
        } else {
            System.out.println("Pattern does not match the input string.");
        }
    }
}
