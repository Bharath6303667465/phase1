package phase1;

public class TypeCastingExample {
    public static void main(String[] args) {
        // Implicit type casting (widening conversion)
        int numInt = 10;
        double numDouble = numInt; // Implicit casting from int to double
        System.out.println("Implicit Casting:");
        System.out.println("numInt = " + numInt);
        System.out.println("numDouble = " + numDouble);

        // Explicit type casting (narrowing conversion)
        double numDouble2 = 15.67;
        int numInt2 = (int) numDouble2; // Explicit casting from double to int
        System.out.println("\nExplicit Casting:");
        System.out.println("numDouble2 = " + numDouble2);
        System.out.println("numInt2 = " + numInt2);
    }
}


