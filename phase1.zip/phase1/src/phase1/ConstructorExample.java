package phase1;

class Person {
    private String name;
    private int age;

    // Default constructor
    public Person() {
        name = "John Doe";
        age = 30;
    }

    // Parameterized constructor
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Copy constructor
    public Person(Person otherPerson) {
        this.name = otherPerson.name;
        this.age = otherPerson.age;
    }

    // Getter methods
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}

public class ConstructorExample {
    public static void main(String[] args) {
        // Creating objects using different constructor types
        Person person1 = new Person(); // Default constructor
        Person person2 = new Person("Alice", 25); // Parameterized constructor
        Person person3 = new Person(person2); // Copy constructor

        // Displaying the information of each person
        System.out.println("Person 1: Name - " + person1.getName() + ", Age - " + person1.getAge());
        System.out.println("Person 2: Name - " + person2.getName() + ", Age - " + person2.getAge());
        System.out.println("Person 3: Name - " + person3.getName() + ", Age - " + person3.getAge());
    }
}
