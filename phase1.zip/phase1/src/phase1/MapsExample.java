package phase1;

import java.util.HashMap;
import java.util.Map;

public class MapsExample {
    public static void main(String[] args) {
        // Creating a HashMap
        Map<String, Integer> studentGrades = new HashMap<>();

        // Adding entries to the map
        studentGrades.put("John", 90);
        studentGrades.put("Alice", 85);
        studentGrades.put("Bob", 92);
        studentGrades.put("Charlie", 88);

        // Accessing values using keys
        int johnGrade = studentGrades.get("John");
        int bobGrade = studentGrades.get("Bob");

        System.out.println("John's grade: " + johnGrade);
        System.out.println("Bob's grade: " + bobGrade);

        // Checking if a key exists
        boolean hasAlice = studentGrades.containsKey("Alice");
        boolean hasDavid = studentGrades.containsKey("David");

        System.out.println("Has Alice? " + hasAlice);
        System.out.println("Has David? " + hasDavid);

        // Updating a value
        studentGrades.put("Alice", 90);

        // Removing an entry
        studentGrades.remove("Charlie");

        // Iterating over the map
        System.out.println("Student Grades:");
        for (Map.Entry<String, Integer> entry : studentGrades.entrySet()) {
            String name = entry.getKey();
            int grade = entry.getValue();
            System.out.println(name + ": " + grade);
        }
    }
}

